export interface user_report{
    report_Id:number,
    user_Id:number,
    firstname:string,
    lastname:string,
    subject_Name:string,
    test_Level:number,
    total_Score:number,
    marks:number,
    pass_Fail: string
}