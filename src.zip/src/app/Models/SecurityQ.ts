export interface Security_Question{
    security_Id: number;
    question_Statement: number;
}