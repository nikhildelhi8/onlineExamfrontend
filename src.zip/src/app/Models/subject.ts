export interface subject{
    
    subject_Id?:number;
    subject_Name:string;
    image_Path:string;
}