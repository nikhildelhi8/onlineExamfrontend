export interface User{
        
        user_Id: number;
        firstname: string;
        lastname: string;
        email: string;
        mobile: string;
        city: string;
        dob: string;
        state: string;
        qualification: string;
        year_of_completion: string;
        password: string;
        confirm_password: string;
        security_Id: number;
        security_Answer: string;
}