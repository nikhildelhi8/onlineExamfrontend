export interface Scanned_Question{
    question_No: number;
    question_Statement: string;
    option_1: string;
    option_2: string;
    option_3: string;
    option_4: string;
    correct_Answer: string;
    question_marks: number;
}