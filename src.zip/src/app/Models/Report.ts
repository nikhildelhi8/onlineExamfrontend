export interface Report{
      report_Id?: number; 
          user_Id: number; 
          test_Id: number;  
          subject_Id: number; 
          total_Score: number;  
          test_Level: number; 
          pass_Fail: string; 
}