export interface forgotPassword{
    user_Id:number,
    email:string,
    password:string,
    confirm_Password:string,
    security_Id:number,
    question_Statement:string,
    security_Answer:string
}