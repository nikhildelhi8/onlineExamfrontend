export interface SearchUser{
    report_Id:number,
    firstname:string,
    lastname:string,
    email:  string,
    mobile:string,
    city:string,
    dob:string,
    state:string,
    qualification:string,
    year_of_completion: string,
    marks:number,
    subject_Name:string,
    total_Score:number,
    test_Level:number,
    pass_Fail:string,
    subject_Id:number
}