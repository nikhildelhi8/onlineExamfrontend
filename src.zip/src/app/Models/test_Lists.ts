export interface test_List{
    test_Id: number;
    subject_Id: number;
    test_Level: number;
    marks: number;
}